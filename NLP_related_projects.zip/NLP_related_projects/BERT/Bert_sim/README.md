This folder is focus on BERT similarity practice. 

The dataset has been put in /data folder and all in csv format.

config.py shows parameters that are used in bert model. Go run run_similarity.py to check the result.

(PS: pay serious attantion to the path either data or initial bert checkpoint when modifying)
