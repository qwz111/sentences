# BERT

## Text Similarity Demo

This catalogue includes one of application of BERT which is Text Similarity. In order to implement a QA system,  based on Knowledge base, we compare the input and known question. If those sentence are similar, we push the answer that is relative to the known question back to one who throw up the input question. 

Any questions will be welcome.

